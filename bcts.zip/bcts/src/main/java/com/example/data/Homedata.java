package com.example.data;

public class Homedata {

	private String Service_Name;
	private int count_four;
	private int count;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	private int count_eight;
	public String getService_Name() {
		return Service_Name;
	}
	public void setService_Name(String service_Name) {
		Service_Name = service_Name;
	}
	public int getCount_four() {
		return count_four;
	}
	public void setCount_four(int count_four) {
		this.count_four = count_four;
	}
	public int getCount_eight() {
		return count_eight;
	}
	public void setCount_eight(int count_eight) {
		this.count_eight = count_eight;
	}
	
}
